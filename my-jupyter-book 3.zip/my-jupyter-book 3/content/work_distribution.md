# Werkverdeling
{% set naam1 = "Frank" %}
{% set naam2 = "Jaïr" %}
{% set naam3 = "Jonas" %}
{% set naam4 = "Finn" %}
## Teamleden en Hun Rollen

### {{ naam1 }}
**Rol:** Projectcoördinator en Data-analyse
- **Verantwoordelijkheden:**
  - Overzicht houden op het project en zorgen voor een tijdige voltooiing van alle onderdelen.
  - Leiden van teamvergaderingen en coördineren van de samenwerking tussen teamleden.
  - Uitvoeren van de data-analyse en preprocessing van de datasets.
  - Bijdragen aan de ontwikkeling van visualisaties en interpreteren van de resultaten.

### {{ naam2 }}
**Rol:** Data-visualisatie Specialist
- **Verantwoordelijkheden:**
  - Ontwerpen en ontwikkelen van de visualisaties voor het project.
  - Zorgen voor consistentie en duidelijkheid in alle grafieken en diagrammen.
  - Implementeren van feedback van teamleden en TA om de visualisaties te verbeteren.
  - Samenwerken met de data-analist om de juiste datasets en methoden te kiezen voor de visualisaties.

### {{ naam3 }}
**Rol:** Schrijver en Editor
- **Verantwoordelijkheden:**
  - Schrijven van de tekst voor de verschillende secties van het Jupyter Book.
  - Zorgen voor een samenhangend en vloeiend verhaal door alle delen van het project.
  - Redigeren en proeflezen van alle teksten om grammaticale fouten en onduidelijkheden te verwijderen.
  - Coördineren met de visualisatiespecialist om ervoor te zorgen dat de tekst en visualisaties goed op elkaar aansluiten.

### {{ naam4 }}
**Rol:** Onderzoeker en Bronverzameling
- **Verantwoordelijkheden:**
  - Verzamelen van relevante bronnen en literatuur om de argumenten in het project te ondersteunen.
  - Documenteren en correct citeren van alle gebruikte bronnen.
  - Bijdragen aan de datasetselectie en ervoor zorgen dat de datasets betrouwbaar en relevant zijn.
  - Ondersteunen bij het schrijven van de tekst en het bieden van inhoudelijke input gebaseerd op het onderzoek.

## Werkverdeling Overzicht

### Data-analyse en Preprocessing
- **Verantwoordelijk:** {{ naam1 }}
- **Bijdragen:** {{ naam4 }} bij datasetselectie en -verificatie.

### Ontwerp en Ontwikkeling van Visualisaties
- **Verantwoordelijk:** {{ naam2 }}
- **Bijdragen:** {{ naam1 }} bij interpretatie van de gegevens en {{ naam3 }} bij de integratie van visualisaties in de tekst.

### Schrijven van de Secties
- **Inleiding:** {{ naam3 }}
- **Dataset en Voorbewerking:** {{ naam1 }} en {{ naam4 }}
- **Perspectief 1:** {{ naam3 }} met input van {{ naam2 }} voor visualisaties.
- **Perspectief 2:** {{ naam3 }} met input van {{ naam2 }} voor visualisaties.
- **Reflectie:** {{ naam1 }} met bijdragen van alle teamleden.
- **Werkverdeling:** {{ naam1 }} en {{ naam3 }}
- **Referenties:** {{ naam4 }}

### Feedback en Revisies
- **Verantwoordelijk voor Implementatie van Feedback:** {{ naam1 }}
- **Bijdragen:** Alle teamleden voor het geven van feedback en het doen van revisies.

## Conclusie
Dankzij de duidelijke werkverdeling en de samenwerking tussen teamleden konden we efficiënt werken en de verschillende onderdelen van het project succesvol afronden. Iedereen droeg bij aan hun expertisegebied, wat resulteerde in een goed afgerond en informatief dataverhaal over plastic recycling.
